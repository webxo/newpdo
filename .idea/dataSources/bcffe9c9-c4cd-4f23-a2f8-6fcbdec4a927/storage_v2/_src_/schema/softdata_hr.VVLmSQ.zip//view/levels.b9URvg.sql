create view levels as
  select `softdata_universitysetup`.`levels`.`levelid` AS `levelid`,
         `softdata_universitysetup`.`levels`.`level`   AS `level`
  from `softdata_universitysetup`.`levels`;


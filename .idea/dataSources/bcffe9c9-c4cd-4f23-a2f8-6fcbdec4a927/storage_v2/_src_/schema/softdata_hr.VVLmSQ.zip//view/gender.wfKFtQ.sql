create view gender as
  select `softdata_universitysetup`.`gender`.`full`          AS `full`,
         `softdata_universitysetup`.`gender`.`id`            AS `id`,
         `softdata_universitysetup`.`gender`.`gender`        AS `gender`,
         `softdata_universitysetup`.`gender`.`gender_status` AS `gender_status`
  from `softdata_universitysetup`.`gender`
  where (`softdata_universitysetup`.`gender`.`gender_status` = 1);


create view rptyear as
  select `rptyear`.`sessionid`    AS `sessionid`,
         `rptyear`.`semesterid`   AS `semesterid`,
         `rptyear`.`semestername` AS `semestername`,
         `rptyear`.`startdate`    AS `startdate`,
         `rptyear`.`enddate`      AS `enddate`,
         `rptyear`.`session`      AS `session`,
         `rptyear`.`shortsem`     AS `shortsem`,
         `rptyear`.`id`           AS `id`
  from `softdata_universitysetup`.`rptyear`;


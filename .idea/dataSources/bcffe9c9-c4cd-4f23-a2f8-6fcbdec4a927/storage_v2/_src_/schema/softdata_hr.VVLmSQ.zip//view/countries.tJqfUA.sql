create view countries as
  select `softdata_universitysetup`.`countries`.`countryid`   AS `countryid`,
         `softdata_universitysetup`.`countries`.`country`     AS `country`,
         `softdata_universitysetup`.`countries`.`countrycode` AS `countrycode`,
         `softdata_universitysetup`.`countries`.`phonecode`   AS `phonecode`,
         `softdata_universitysetup`.`countries`.`nationality` AS `nationality`,
         `softdata_universitysetup`.`countries`.`currency`    AS `currency`,
         `softdata_universitysetup`.`countries`.`region`      AS `region`
  from `softdata_universitysetup`.`countries`;


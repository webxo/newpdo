create view posts as
  select `softdata_universitysetup`.`posts`.`postid`   AS `postid`,
         `softdata_universitysetup`.`posts`.`post`     AS `post`,
         `softdata_universitysetup`.`posts`.`category` AS `category`,
         `softdata_universitysetup`.`posts`.`ct`       AS `ct`
  from `softdata_universitysetup`.`posts`
  where (`softdata_universitysetup`.`posts`.`poststatus` = '1');


create view cuaux as
  select `softdata_payroll`.`cuaux`.`sallevel` AS `sallevel`,
         `softdata_payroll`.`cuaux`.`mgros`    AS `mgros`,
         `softdata_payroll`.`cuaux`.`mbasic`   AS `mbasic`,
         `softdata_payroll`.`cuaux`.`mrent`    AS `mrent`,
         `softdata_payroll`.`cuaux`.`mpecu`    AS `mpecu`
  from `softdata_payroll`.`cuaux`;


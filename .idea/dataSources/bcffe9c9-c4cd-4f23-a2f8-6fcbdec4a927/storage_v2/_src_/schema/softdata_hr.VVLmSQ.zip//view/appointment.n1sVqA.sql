create view appointment as
  select `softdata_hr`.`appointmenthistory`.`idno`         AS `idno`,
         `softdata_hr`.`appointmenthistory`.`tenurestart`  AS `tenurestart`,
         `softdata_hr`.`appointmenthistory`.`tenureend`    AS `tenureend`,
         `softdata_hr`.`appointmenthistory`.`allowance`    AS `allowance`,
         `softdata_hr`.`appointmenthistory`.`post`         AS `post`,
         `softdata_hr`.`appointmenthistory`.`remark`       AS `remark`,
         `softdata_hr`.`appointmenthistory`.`unit`         AS `unit`,
         `softdata_hr`.`appointmenthistory`.`staffid`      AS `staffid`,
         `softdata_hr`.`appointmenthistory`.`id`           AS `id`,
         `softdata_hr`.`appointmenthistory`.`datecreated`  AS `datecreated`,
         `softdata_hr`.`appointmenthistory`.`datemodified` AS `datemodified`
  from `softdata_hr`.`appointmenthistory`
  where (`softdata_hr`.`appointmenthistory`.`tenureend` = '0000-00-00');


create view religion as
  select `softdata_universitysetup`.`religion`.`relid`      AS `relid`,
         `softdata_universitysetup`.`religion`.`rel`        AS `rel`,
         `softdata_universitysetup`.`religion`.`reslstatus` AS `reslstatus`
  from `softdata_universitysetup`.`religion`
  where (`softdata_universitysetup`.`religion`.`reslstatus` = 1);


create view programs as
  select `softdata_universitysetup`.`programs`.`kolid`         AS `kolid`,
         `softdata_universitysetup`.`programs`.`dip`           AS `dip`,
         `softdata_universitysetup`.`programs`.`deptid`        AS `deptid`,
         `softdata_universitysetup`.`programs`.`program`       AS `program`,
         `softdata_universitysetup`.`programs`.`prgid`         AS `prgid`,
         `softdata_universitysetup`.`programs`.`programstatus` AS `programstatus`
  from `softdata_universitysetup`.`programs`;


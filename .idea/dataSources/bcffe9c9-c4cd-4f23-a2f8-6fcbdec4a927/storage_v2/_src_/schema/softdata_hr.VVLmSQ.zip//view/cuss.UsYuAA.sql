create view cuss as
  select `softdata_payroll`.`cuss`.`sallevel`  AS `sallevel`,
         `softdata_payroll`.`cuss`.`agros`     AS `agros`,
         `softdata_payroll`.`cuss`.`abasic`    AS `abasic`,
         `softdata_payroll`.`cuss`.`arent`     AS `arent`,
         `softdata_payroll`.`cuss`.`apecu`     AS `apecu`,
         `softdata_payroll`.`cuss`.`increment` AS `increment`,
         `softdata_payroll`.`cuss`.`mgros`     AS `mgros`,
         `softdata_payroll`.`cuss`.`mbasic`    AS `mbasic`,
         `softdata_payroll`.`cuss`.`mrent`     AS `mrent`,
         `softdata_payroll`.`cuss`.`mpecu`     AS `mpecu`
  from `softdata_payroll`.`cuss`;


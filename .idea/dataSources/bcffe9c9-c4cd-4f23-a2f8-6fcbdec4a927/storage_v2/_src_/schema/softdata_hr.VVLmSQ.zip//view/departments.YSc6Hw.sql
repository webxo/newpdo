create view departments as
  select `softdata_universitysetup`.`departments`.`kolid`            AS `kolid`,
         `softdata_universitysetup`.`departments`.`dpid`             AS `dpid`,
         `softdata_universitysetup`.`departments`.`department`       AS `department`,
         `softdata_universitysetup`.`departments`.`dpno`             AS `dpno`,
         `softdata_universitysetup`.`departments`.`departmentstatus` AS `departmentstatus`
  from `softdata_universitysetup`.`departments`;


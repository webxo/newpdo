create view steps as
  select `softdata_universitysetup`.`steps`.`stepid` AS `stepid`, `softdata_universitysetup`.`steps`.`step` AS `step`
  from `softdata_universitysetup`.`steps`;


create view cutss as
  select `softdata_payroll`.`cutss`.`sallevel`  AS `sallevel`,
         `softdata_payroll`.`cutss`.`agros`     AS `agros`,
         `softdata_payroll`.`cutss`.`abasic`    AS `abasic`,
         `softdata_payroll`.`cutss`.`arent`     AS `arent`,
         `softdata_payroll`.`cutss`.`apecu`     AS `apecu`,
         `softdata_payroll`.`cutss`.`increment` AS `increment`,
         `softdata_payroll`.`cutss`.`mgros`     AS `mgros`,
         `softdata_payroll`.`cutss`.`mbasic`    AS `mbasic`,
         `softdata_payroll`.`cutss`.`mrent`     AS `mrent`,
         `softdata_payroll`.`cutss`.`mpecu`     AS `mpecu`
  from `softdata_payroll`.`cutss`;


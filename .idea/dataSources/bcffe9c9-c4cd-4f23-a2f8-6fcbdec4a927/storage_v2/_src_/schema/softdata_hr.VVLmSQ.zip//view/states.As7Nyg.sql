create view states as
  select `softdata_universitysetup`.`states`.`state_id`    AS `state_id`,
         `softdata_universitysetup`.`states`.`state_name`  AS `state_name`,
         `softdata_universitysetup`.`states`.`state_code`  AS `state_code`,
         `softdata_universitysetup`.`states`.`countrycode` AS `countrycode`,
         `softdata_universitysetup`.`states`.`countryid`   AS `countryid`
  from `softdata_universitysetup`.`states`;


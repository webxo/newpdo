create view categories as
  select `softdata_universitysetup`.`categories`.`ct`        AS `ct`,
         `softdata_universitysetup`.`categories`.`category`  AS `category`,
         `softdata_universitysetup`.`categories`.`salprefix` AS `salprefix`,
         `softdata_universitysetup`.`categories`.`catstatus` AS `catstatus`
  from `softdata_universitysetup`.`categories`;


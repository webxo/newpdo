create view banks as
  select `softdata_payroll`.`banks`.`bkid`       AS `bkid`,
         `softdata_payroll`.`banks`.`bankname`   AS `bankname`,
         `softdata_payroll`.`banks`.`bankstatus` AS `bankstatus`,
         `softdata_payroll`.`banks`.`id`         AS `id`
  from `softdata_payroll`.`banks`;


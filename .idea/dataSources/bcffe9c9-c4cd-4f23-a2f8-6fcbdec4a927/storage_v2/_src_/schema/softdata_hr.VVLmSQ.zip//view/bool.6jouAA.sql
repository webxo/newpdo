create view bool as
  select `softdata_universitysetup`.`bool`.`boolid` AS `boolid`, `softdata_universitysetup`.`bool`.`bool` AS `bool`
  from `softdata_universitysetup`.`bool`;


create view titles as
  select `softdata_universitysetup`.`titles`.`id`          AS `id`,
         `softdata_universitysetup`.`titles`.`title`       AS `title`,
         `softdata_universitysetup`.`titles`.`titlestatus` AS `titlestatus`
  from `softdata_universitysetup`.`titles`;


create view stateoflife as
  select `softdata_universitysetup`.`stateoflife`.`id`         AS `id`,
         `softdata_universitysetup`.`stateoflife`.`livingstat` AS `livingstat`
  from `softdata_universitysetup`.`stateoflife`;


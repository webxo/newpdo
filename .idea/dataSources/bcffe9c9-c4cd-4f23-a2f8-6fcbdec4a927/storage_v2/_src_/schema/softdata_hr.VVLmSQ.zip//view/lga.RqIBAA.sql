create view lga as
  select `softdata_universitysetup`.`lga`.`lga_id`   AS `lga_id`,
         `softdata_universitysetup`.`lga`.`state_id` AS `state_id`,
         `softdata_universitysetup`.`lga`.`lga_name` AS `lga_name`
  from `softdata_universitysetup`.`lga`;


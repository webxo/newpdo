create view colleges as
  select `softdata_universitysetup`.`colleges`.`colid`         AS `colid`,
         `softdata_universitysetup`.`colleges`.`college`       AS `college`,
         `softdata_universitysetup`.`colleges`.`full`          AS `full`,
         `softdata_universitysetup`.`colleges`.`colno`         AS `colno`,
         `softdata_universitysetup`.`colleges`.`dean`          AS `dean`,
         `softdata_universitysetup`.`colleges`.`staffid`       AS `staffid`,
         `softdata_universitysetup`.`colleges`.`collegestatus` AS `collegestatus`
  from `softdata_universitysetup`.`colleges`;


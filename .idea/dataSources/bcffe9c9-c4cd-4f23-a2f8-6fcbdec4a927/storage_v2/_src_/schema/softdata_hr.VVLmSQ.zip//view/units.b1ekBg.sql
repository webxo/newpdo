create view units as
  select `softdata_universitysetup`.`units`.`unitid`     AS `unitid`,
         `softdata_universitysetup`.`units`.`unit`       AS `unit`,
         `softdata_universitysetup`.`units`.`unitno`     AS `unitno`,
         `softdata_universitysetup`.`units`.`unitstatus` AS `unitstatus`
  from `softdata_universitysetup`.`units`;


create view cuass as
  select `softdata_payroll`.`cuass`.`sallevel`  AS `sallevel`,
         `softdata_payroll`.`cuass`.`agros`     AS `agros`,
         `softdata_payroll`.`cuass`.`abasic`    AS `abasic`,
         `softdata_payroll`.`cuass`.`arent`     AS `arent`,
         `softdata_payroll`.`cuass`.`apecu`     AS `apecu`,
         `softdata_payroll`.`cuass`.`increment` AS `increment`,
         `softdata_payroll`.`cuass`.`mgros`     AS `mgros`,
         `softdata_payroll`.`cuass`.`mbasic`    AS `mbasic`,
         `softdata_payroll`.`cuass`.`mrent`     AS `mrent`,
         `softdata_payroll`.`cuass`.`mpecu`     AS `mpecu`
  from `softdata_payroll`.`cuass`;

